import os

class Config:
    SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URL', 'sqlite:///wallet.db')
    JWT_SECRET_KEY = os.getenv('JWT_SECRET', 'your-strong-secret-here')
    SUPPORTED_CURRENCIES = ['USD', 'EUR', 'GBP', 'INR']
    FRAUD_THRESHOLDS = {
        'MAX_TRANSACTIONS_PER_MIN': 5,
        'LARGE_TRANSACTION': 10000,
        'IP_CHANGE_SENSITIVITY': True,
        'DAILY_SCAN_HOUR': 3  # Runs at 3 AM daily
    }
