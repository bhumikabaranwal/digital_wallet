from flask import Flask, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager
from apscheduler.schedulers.background import BackgroundScheduler
import logging

db = SQLAlchemy()
bcrypt = Bcrypt()
jwt = JWTManager()
scheduler = BackgroundScheduler()

def create_app(config_class='config.Config'):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Initialize extensions
    db.init_app(app)
    bcrypt.init_app(app)
    jwt.init_app(app)

    # Register blueprints
    from app.routes import api
    app.register_blueprint(api)

    # Error handlers
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({"error": "Resource not found"}), 404

    @app.errorhandler(500)
    def server_error(error):
        return jsonify({"error": "Internal server error"}), 500

    # Initialize scheduler
    if not app.debug or os.environ.get('WERKZEUG_RUN_MAIN') == 'true':
        try:
            from app.services import daily_fraud_scan
            scheduler.add_job(
                daily_fraud_scan,
                'cron',
                hour=app.config['FRAUD_THRESHOLDS']['DAILY_SCAN_HOUR'],
                args=[app]
            )
            scheduler.start()
        except Exception as e:
            logging.error(f"Scheduler error: {str(e)}")

    return app
