from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, create_access_token, get_jwt_identity, get_jwt
from app import bcrypt, db
from app.models import User, Transaction
from app.services import detect_fraud, log_fraud_attempt
from flasgger import swag_from
from datetime import datetime

api = Blueprint('api', __name__)

@api.route('/register', methods=['POST'])
@swag_from('../docs/register.yml')
def register():
    data = request.get_json()
    if User.query.filter_by(username=data['username']).first():
        return jsonify({"error": "Username exists"}), 400

    hashed_pw = bcrypt.generate_password_hash(data['password']).decode('utf-8')
    user = User(
        username=data['username'],
        password_hash=hashed_pw,
        currency=data.get('currency', 'USD')
    )
    db.session.add(user)
    db.session.commit()
    return jsonify(message="User registered"), 201

@api.route('/login', methods=['POST'])
@swag_from('../docs/login.yml')
def login():
    data = request.get_json()
    user = User.query.filter_by(username=data['username']).first()

    if user and bcrypt.check_password_hash(user.password_hash, data['password']):
        token = create_access_token(identity=user.id)
        return jsonify(token=token)
    
    return jsonify({"error": "Invalid credentials"}), 401

@api.route('/withdraw', methods=['POST'])
@jwt_required()
@swag_from('../docs/withdraw.yml')
def withdraw():
    user_id = get_jwt_identity()
    data = request.get_json()
    user = User.query.get(user_id)

    if data['amount'] <= 0 or user.balance < data['amount']:
        return jsonify({"error": "Invalid withdrawal amount"}), 400

    user.balance -= data['amount']
    txn = Transaction(
        sender_id=user_id,
        amount=data['amount'],
        currency=data.get('currency', user.currency),
        type='withdraw',
        flagged=detect_fraud(
            user_id,
            data['amount'],
            data.get('currency', user.currency),
            request.remote_addr
        )
    )
    db.session.add(txn)
    db.session.commit()
    return jsonify(message="Withdrawal successful")

@api.route('/transfer', methods=['POST'])
@jwt_required()
@swag_from('../docs/transfer.yml')
def transfer():
    user_id = get_jwt_identity()
    data = request.get_json()
    
    sender = User.query.get(user_id)
    recipient = User.query.filter_by(username=data['to']).first()

    if not recipient or recipient.is_deleted:
        return jsonify({"error": "Invalid recipient"}), 400
    if data['amount'] <= 0 or sender.balance < data['amount']:
        return jsonify({"error": "Invalid transfer amount"}), 400

    sender.balance -= data['amount']
    recipient.balance += data['amount']

    txn = Transaction(
        sender_id=user_id,
        receiver_id=recipient.id,
        amount=data['amount'],
        currency=data.get('currency', sender.currency),
        type='transfer',
        flagged=detect_fraud(
            user_id,
            data['amount'],
            data.get('currency', sender.currency),
            request.remote_addr
        )
    )
    db.session.add(txn)
    db.session.commit()
    return jsonify(message="Transfer successful")

@api.route('/transactions', methods=['GET'])
@jwt_required()
@swag_from('../docs/transactions.yml')
def get_transactions():
    user_id = get_jwt_identity()
    txns = Transaction.query.filter(
        (Transaction.sender_id == user_id) |
        (Transaction.receiver_id == user_id),
        Transaction.is_deleted == False
    ).all()
    return jsonify([{
        'id': t.id,
        'type': t.type,
        'amount': t.amount,
        'currency': t.currency,
        'timestamp': t.timestamp.isoformat(),
        'flagged': t.flagged
    } for t in txns])

# Admin Endpoints
@api.route('/admin/flags', methods=['GET'])
@jwt_required()
@swag_from('../docs/admin_flags.yml')
def get_flagged_transactions():
    # In production, add role checking here
    txns = Transaction.query.filter_by(flagged=True).all()
    return jsonify([{
        'id': t.id,
        'sender_id': t.sender_id,
        'amount': t.amount,
        'currency': t.currency,
        'type': t.type,
        'timestamp': t.timestamp.isoformat()
    } for t in txns])

@api.route('/admin/delete/<int:txn_id>', methods=['DELETE'])
@jwt_required()
@swag_from('../docs/admin_delete.yml')
def soft_delete_transaction(txn_id):
    txn = Transaction.query.get(txn_id)
    if not txn:
        return jsonify({"error": "Transaction not found"}), 404
    
    txn.is_deleted = True
    db.session.commit()
    return jsonify(message="Transaction soft deleted")
