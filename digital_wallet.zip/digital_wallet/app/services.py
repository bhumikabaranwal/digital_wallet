from datetime import datetime, timedelta
from app import db
from app.models import Transaction, User
import logging
from flask import current_app

def detect_fraud(user_id, amount, currency, ip_address=None):
    """Enhanced fraud detection with IP tracking"""
    now = datetime.utcnow()
    
    # Check transaction frequency
    recent_txns = Transaction.query.filter(
        Transaction.sender_id == user_id,
        Transaction.currency == currency,
        Transaction.timestamp > now - timedelta(minutes=1),
        Transaction.is_deleted == False
    ).count()

    # Check amount threshold
    if (recent_txns > current_app.config['FRAUD_THRESHOLDS']['MAX_TRANSACTIONS_PER_MIN'] or
        amount > current_app.config['FRAUD_THRESHOLDS']['LARGE_TRANSACTION']):
        return True

    # IP change detection
    if current_app.config['FRAUD_THRESHOLDS']['IP_CHANGE_SENSITIVITY'] and ip_address:
        user = User.query.get(user_id)
        if user.last_ip and user.last_ip != ip_address:
            return True
        user.last_ip = ip_address
        db.session.commit()

    return False

def daily_fraud_scan(app):
    """Complete scheduled scan implementation"""
    with app.app_context():
        try:
            yesterday = datetime.utcnow() - timedelta(days=1)
            suspicious = Transaction.query.filter(
                Transaction.timestamp > yesterday,
                Transaction.flagged == False,
                Transaction.is_deleted == False
            ).all()

            for txn in suspicious:
                if detect_fraud(txn.sender_id, txn.amount, txn.currency):
                    txn.flagged = True
                    log_fraud_attempt(txn)
            
            db.session.commit()
            logging.info("Daily fraud scan completed successfully")
        except Exception as e:
            logging.error(f"Fraud scan failed: {str(e)}")
            db.session.rollback()

def log_fraud_attempt(txn):
    """Complete notification service"""
    logging.warning(
        f"Fraud alert!\n"
        f"Transaction ID: {txn.id}\n"
        f"Amount: {txn.amount} {txn.currency}\n"
        f"Type: {txn.type}\n"
        f"Sender: {txn.sender_id}\n"
        f"Time: {txn.timestamp}"
    )
    
    # In production:
    # from app.email_service import send_alert
    # send_alert(to="security@company.com", transaction=txn)

